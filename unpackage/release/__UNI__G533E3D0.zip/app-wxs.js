var __wxsModules={};
__wxsModules["37368788"]=(()=>{var u=(r,e)=>()=>(e||r((e={exports:{}}).exports,e),e.exports);var i=u((l,t)=>{var n={abbr:!0,b:!0,big:!0,code:!0,del:!0,em:!0,i:!0,ins:!0,label:!0,q:!0,small:!0,span:!0,strong:!0,sub:!0,sup:!0};t.exports={isInline:function(r,e){return n[r]||(e||"").indexOf("display:inline")!==-1}}});return i();})();
